package problems;

/**
 * Calcula o floor e ceil de um numero em um array usando a estrategia de busca
 * binaria.
 * 
 * Restricoes: 
 * - Algoritmo in-place (nao pode usar memoria extra a nao ser variaveis locais) 
 * - O tempo de seu algoritmo deve ser O(log n).
 * 
 * @author Adalberto
 *
 */
public class FloorCeilBinarySearchImpl implements FloorCeil {

	@Override
	public Integer floor(Integer[] array, Integer x) {
		return floor(array, x, 0, array.length - 1);
	}

	private Integer floor(Integer[] array, Integer x, Integer inicio, Integer fim) {

		Integer floor = null;

		if(array != null && array.length != 0 && inicio <= fim) {
			Integer meio = (inicio + fim) / 2;

			if(array[meio].compareTo(x) == 0) {
				floor = array[meio];
			} else if(array[meio].compareTo(x) < 0) {
				Integer possivelFloor = floor(array, x, meio + 1, fim);
				if(possivelFloor != null) {
					floor = possivelFloor;
				} else {
					floor = array[meio];
				}
			} else {
				floor = floor(array, x, inicio, meio - 1);
			}
		}
		return floor;
	}


 	@Override
    public Integer ceil(Integer[] array, Integer x) {
        return ceil(array, x, 0, array.length - 1);
    }

    private Integer ceil(Integer[] array, Integer x, Integer inicio, Integer fim) {
        
		Integer ceil = null;

        if (array != null && array.length != 0 && inicio <= fim) {
            Integer meio = (inicio + fim) / 2;

            if (array[meio].compareTo(x) == 0) {
                ceil = array[meio];
            } else if (array[meio].compareTo(x) > 0) {
                Integer possivelCeil = ceil(array, x, inicio, meio - 1);
                if (possivelCeil != null) {
                    ceil = possivelCeil;
                } else {
                    ceil = array[meio];
                }
            } else {
                ceil = ceil(array, x, meio + 1, fim);
            }
        }
        return ceil;
    }

}
